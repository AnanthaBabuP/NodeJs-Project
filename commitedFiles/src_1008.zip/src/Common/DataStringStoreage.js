const commonObject = {
    InvalidLogin : 'Please Enter Valid UserName And Password!!',
    PAGE_COUNT_10 : 10,
    PAGE_COUNT_05 : 5,
    EmptyString : ''
};

// Export the object and function
module.exports = {
    commonObject
};