## NPM INSTALL process
## npm init -y 

## RUN process
## npm run dev

## Install Process : npm install <PackageName>




## IMPORT CODE 

## npm install express express-session body-parser ejs mongodb
<!-- npm install --save-dev @types/node -->

## COMMITE PROCESS 
## 1001 commit with propere stucture creating process not done commit.
## 1002 commit On 1st stage process complition for conect with web on proper file stucture
## 1003 commit On 2st stage process complition for conect with web on proper file stucture
## 1004 commit FOR Login Form With Data Retrive in MONGODB Source
