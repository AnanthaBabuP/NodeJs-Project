const commonObject = {
    InvalidLogin : 'Please Enter Valid UserName And Password!!',
    EmptyString : ''
};

// Export the object and function
module.exports = {
    commonObject
};